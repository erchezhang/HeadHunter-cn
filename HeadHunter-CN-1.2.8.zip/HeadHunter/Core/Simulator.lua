-- HH-005: inject fake data so rules, alerts and UI can be tested without real gankers.
--
--   /hh sim death "<name>" <level|skull> <CLASS> <RACE> [sex]
--   /hh sim sighting "<name>" <level|skull> <CLASS> <RACE> [sex]
--   /hh sim demo [clear]   every tab filled with a made-up story (Core/Demo.lua)
--   /hh sim send ...       simulated deaths shared with other characters (debug)
--   /hh sim clear          remove every simulated death and test catch
--   /hh sim duels [clear]  test duel spots in our zone, only on our screen (HH-134)
--   /hh sim buckles [clear] made-up buckle finds of our character, the reveal at once and
--                          the worn one on our tooltip; this session only (HH-161)
--   /hh sim gang [me|clear] the Wild Bunch for screenshots: Butch Cassidy leads (me, or a
--                          character named Butch Cassidy: we do),
--                          with the outlaws of the 1890s; this session only (HH-155)
--
-- Forever names contain a space, so quote them: /hh sim death "Grim Reaper" skull ROGUE Human
-- Simulated data goes through the same internal events as real data:
--   HH_DEATH_REPORT(report, source)   consumed from HH-013 on
--   HH_ENEMY_SEEN(enemy, source)      consumed from HH-010 on

local addonName, ns = ...
local L = ns.L

local Simulator = ns:RegisterModule("Simulator", {})

-- The Wild Bunch (the Hole-in-the-Wall Gang) of the 1890s, for /hh sim gang, all Horde:
-- name, class, level, online, race, sex (2 male, 3 female)
Simulator.WILD_BUNCH = {
    { "Butch Cassidy", "ROGUE", 60, true, "Orc", 2 },
    { "Sundance Kid", "HUNTER", 60, true, "Troll", 2 },
    { "Kid Curry", "WARRIOR", 58, true, "Tauren", 2 },
    { "Elzy Lay", "MAGE", 57, false, "Scourge", 2 },
    { "Ben Kilpatrick", "WARRIOR", 55, true, "Orc", 2 },
    { "Will Carver", "PRIEST", 54, false, "Scourge", 2 },
    { "Laura Bullion", "WARLOCK", 52, true, "Orc", 3 },
    { "Etta Place", "MAGE", 51, false, "Troll", 3 },
    { "George Curry", "DRUID", 50, true, "Tauren", 2 },
}
-- What the gang says in gang chat on the screenshot: sender index, text
Simulator.WILD_BUNCH_CHAT = {
    { 1, "Train leaves Ratchet at dusk. Saddle up." },
    { 2, "I'll take the ridge and cover the bridge." },
    { 7, "Posse spotted near the Crossroads, three riders." },
    { 3, "Let them come. We ride at sundown." },
}

local CLASSES = {
    WARRIOR = true, PALADIN = true, HUNTER = true, ROGUE = true, PRIEST = true,
    SHAMAN = true, MAGE = true, WARLOCK = true, DRUID = true,
}

local serial = 0

-- Returns an enemy record or nil + usage error
function Simulator:ParseEnemy(args)
    local U = ns.Utils
    local key = U.PlayerKey(args[1])
    if not key then
        return nil, string.format(L.SIM_BAD_NAME, tostring(args[1]))
    end
    local levelArg = args[2] and args[2]:lower()
    local level = levelArg == "skull" and -1 or tonumber(levelArg)
    local class = args[3] and args[3]:upper()
    local race = args[4]
    if not level or not CLASSES[class] or not race then
        return nil
    end
    local sex = tonumber(args[5])
    if sex ~= 2 and sex ~= 3 then sex = 1 end
    return {
        key = key,
        level = level,
        class = class,
        race = race,
        sex = sex,
        lastSeen = U.ServerTime(),
    }
end

local function PlayerSnapshot()
    local U = ns.Utils
    return {
        key = U.UnitKey("player"),
        level = U.UnitLevel("player"),
        class = U.UnitClass("player"),
        race = U.UnitRace("player"),
    }
end

-- Same shape as a real death report (HH-013)
function Simulator:BuildDeathReport(killer)
    local U = ns.Utils
    local now = U.ServerTime()
    serial = serial + 1
    local victim = PlayerSnapshot()
    local mapID = U.PlayerMapID()
    local x, y = U.PlayerPosition(mapID)
    return {
        id = string.format("%s:%d:sim%d", victim.key or "?", now, serial),
        t = now,
        victim = victim,
        killer = killer,
        assists = {},
        mapID = mapID,
        x = x,
        y = y,
        confidence = "sim",
    }
end

local function Describe(enemy)
    local level = enemy.level == -1 and "skull" or tostring(enemy.level)
    return string.format("%s %s %s", level, enemy.race, enemy.class)
end

-- /hh sim send "<killer>" [kills] [level|skull] [CLASS] [RACE] ["Zone"]
-- Debug only. Simulated deaths OF THIS CHARACTER, sent over the real sync so a
-- second character receives them (two-character tests of alerts and posses).
-- Must run from the typed command: on Era the realm-wide send needs that
-- hardware event.
-- After the kill count the values may come in any order: a number or "skull" is the
-- level, a class token the class, a zone name the place (its middle; default: where we
-- stand), anything else the race.
function Simulator.SendOptions(args)
    local options = { level = 60, class = "ROGUE", race = "Orc" }
    local levelSet = false
    for i = 3, #args do
        local value = args[i]
        local lower = value:lower()
        if not levelSet and (lower == "skull" or tonumber(value)) then
            options.level = lower == "skull" and -1 or tonumber(value)
            levelSet = true
        elseif CLASSES[value:upper()] then
            options.class = value:upper()
        elseif ns.Zones.FindByName(value) then
            options.mapID = ns.Zones.FindByName(value)
        else
            options.race = value
        end
    end
    return options
end

-- Refused where the zone cannot be read: other players would see "an unknown zone"
-- (HH-123). A named zone always works.
function Simulator:Send(args)
    local U = ns.Utils
    if not ns.debugMode then
        ns:Print(L.SIM_SEND_NEEDS_DEBUG)
        return
    end
    local key = U.PlayerKey(args[1])
    local count = tonumber(args[2]) or 1
    if not key or count < 1 or count > 10 then
        ns:Print(L.SIM_SEND_USAGE)
        return
    end
    local options = Simulator.SendOptions(args)
    local level, class, race = options.level, options.class, options.race

    local victim = PlayerSnapshot()
    local mapID, x, y = options.mapID, 0.5, 0.5
    if not mapID then
        mapID = U.PlayerMapID()
        x, y = U.PlayerPosition(mapID)
    end
    if not mapID or not x then
        ns:Print(L.SIM_SEND_NO_ZONE)
        return
    end
    local now = U.ServerTime()
    local records = {}
    for i = 1, count do
        local t = now - (count - i) * 60
        local report = {
            id = victim.key .. ":" .. t,
            t = t,
            victim = { key = victim.key, level = victim.level, class = victim.class, race = victim.race },
            killer = { key = key, name = key, level = level, class = class, race = race },
            assists = {},
            mapID = mapID, x = x, y = y,
            layer = not options.mapID and ns.Layer:Current() or nil, -- layers compare within one zone
            confidence = "sim",
            shared = true, -- sent to other HeadHunters, so login catch-up may pass it on
        }
        if ns.Reports:Add(report, "sim") then
            local record = ns.Protocol.EncodeDeath(report,
                ns.Protocol.MAX_MESSAGE - 4 - #ns.Transport.CHAT_MARK)
            if record then
                records[#records + 1] = record
                ns.Transport:Queue(ns.Protocol.TYPES.DEATH, record, ns.Transport.PRIORITY.alert, "D:" .. report.id)
            end
        end
    end
    if ns.Transport:RealmWideNeedsClick() and #records > 0 then
        ns.Transport:SendRealmWide(ns.Protocol.TYPES.DEATH, records)
    end
    ns:Print(string.format(L.SIM_SENT, #records, U.DisplayName(key), U.MapName(mapID) or L.UNKNOWN_ZONE))
end

-- /hh sim clear: removes every simulated death (our own and those other characters sent
-- with /hh sim send or /hh spree) and our /hh catch test catches. Outlaws left with no
-- kills drop out of WANTED, At large and the Hall of Shame with the next recompute.
-- Each test character clears its own data; bounty earned in tests stays.
function Simulator:Clear()
    local db = ns.db
    if not db then return nil end
    local removed = { reports = 0, deaths = 0, catches = 0 }
    for id, report in pairs(db.reports or {}) do
        if type(report) == "table" and report.confidence == "sim" and not report.demo then
            db.reports[id] = nil
            removed.reports = removed.reports + 1
        end
    end
    local kept = {}
    for _, report in ipairs(db.deaths or {}) do
        if type(report) == "table" and report.confidence == "sim" and not report.demo then
            removed.deaths = removed.deaths + 1
        else
            kept[#kept + 1] = report
        end
    end
    db.deaths = kept
    for id, record in pairs(db.justice or {}) do
        if type(record) == "table" and record.how == "sim" then
            db.justice[id] = nil
            removed.catches = removed.catches + 1
        end
    end
    ns.Wanted:RequestRecompute()
    return removed
end

-- /hh sim event ongoing|upcoming|clear (HeadHunter_Dev only): a made-up event of our
-- faction and level on the Events tab, being played now or starting later. Kept in
-- memory only; a /reload or clear takes it away.
Simulator.EVENT_PLAYERS = { "Testone", "Testtwo", "Testthree", "Testfour" }
Simulator.EVENT_LATER = 2 * 3600   -- an upcoming one starts this many seconds from now
Simulator.EVENT_STARTED = 600      -- an ongoing one started this many seconds ago
Simulator.EVENT_LOCK = 3600        -- locked this long before the start, as on the website
local testEvents = 0

function Simulator:Event(kind)
    if not ns.Dev.Present() then
        ns:Print(L.SIM_EVENT_NEEDS_DEV)
        return
    end
    if kind == "clear" then
        ns:Print(string.format(L.SIM_EVENT_CLEARED, ns.SiteData:ClearTestTournaments()))
    elseif kind == "ongoing" or kind == "upcoming" then
        local U = ns.Utils
        local now = U.ServerTime()
        local startsAt = kind == "ongoing" and now - self.EVENT_STARTED or now + self.EVENT_LATER
        local level = U.UnitLevel("player") or 1
        local realm = U.PlayerRealm()
        local players = {}
        for i, name in ipairs(self.EVENT_PLAYERS) do
            players[i] = { entrant = "p" .. i, name = name, realm = realm }
        end
        testEvents = testEvents + 1
        local t = ns.SiteData:AddTestTournament({
            id = "test-" .. testEvents, name = string.format(L.SIM_EVENT_NAME, testEvents), venue = "gurubashi",
            format = "1v1", best_of = 1, faction = false, min_level = level, max_level = level, places = 8,
            starts_at = startsAt, locks_at = startsAt - self.EVENT_LOCK, signups_closed = false,
            host = { name = U.UnitName("player"), realm = realm }, organizers = {}, players = players, teams = {},
        })
        if t then ns:Print(string.format(L.SIM_EVENT_ADDED, t.name, kind == "ongoing" and L.TAB_ONGOING or L.TAB_UPCOMING)) end
    else
        ns:Print(L.SIM_USAGE_EVENT)
        return
    end
    if ns.MainWindow and ns.MainWindow.Refresh then ns.MainWindow:Refresh() end
end

-- /hh sim gang: the Wild Bunch as our confirmed gang for screenshots (me: we lead it), with a
-- few gang chat lines; clear: gone
function Simulator:Gang(mode)
    if mode == "clear" then
        ns.Gangs:SetSim(nil)
        ns:Print(L.SIM_GANG_CLEARED)
        return
    end
    local U = ns.Utils
    local me = U.UnitKey("player")
    local _, myClass = UnitClass and UnitClass("player")
    local leads = mode == "me" or (me ~= nil and U.SameCharacter(me, self.WILD_BUNCH[1][1]))
    local members = {}
    for _, m in ipairs(self.WILD_BUNCH) do
        if not (me and U.SameCharacter(me, m[1])) then
            members[#members + 1] = { key = m[1], class = m[2], level = m[3], online = m[4], race = m[5], sex = m[6],
                faction = "Horde" }
        end
    end
    if me then
        local _, myRace = UnitRace and UnitRace("player")
        table.insert(members, leads and 1 or 2, { key = me, class = myClass, level = UnitLevel and UnitLevel("player"),
            race = myRace, sex = UnitSex and UnitSex("player"), faction = UnitFactionGroup and UnitFactionGroup("player") })
    end
    local leader = leads and me or self.WILD_BUNCH[1][1]
    ns.Gangs:SetSim({ name = "Wild Bunch", leader = leader, members = members, confirmed = true, faction = "Horde" })
    local window = DEFAULT_CHAT_FRAME
    if window and window.AddMessage then
        for _, line in ipairs(self.WILD_BUNCH_CHAT) do
            window:AddMessage(ns.GangChat.Line(self.WILD_BUNCH[line[1]][1], line[2]), ns.GangChat.Color())
        end
    end
    ns:Print(L.SIM_GANG_DONE)
end

-- /hh sim buckles: what our character could find, one of each quality and an award, oldest
-- first: buckle, quality, source, the other player or tournament, hours ago
Simulator.TEST_BUCKLES = {
    { "tin_star", "uncommon", "hunter_kill", "Moo Mello", 30 },
    { "upset_at_high_noon", "rare", "duel_upset", "Grim Tusk", 20 },
    { "saloon_royalty", "epic", "glass", "Gank Master", 12 },
    { "champion", "awarded", "award", "Gate Brawl", 6 },
    { "dead_mans_hand", "legendary", "hunter_kill", "Iron Maple", 2 },
}

-- /hh sim buckles [clear] (HH-161): made-up finds of our character for this session (ids
-- below 0, never the website's), wearing the Legendary; the reveal opens at once, and again
-- each time, as their shown marks are removed first. Never saved in the download or sent.
function Simulator:Buckles(mode)
    local shown = ns.db and ns.db.bucklesShown or {}
    for _, find in ipairs(ns.SiteData:ClearTestBuckles()) do shown[tostring(find.uid)] = nil end
    if mode == "clear" then
        ns:Print(L.SIM_BUCKLES_CLEARED)
        return
    end
    local U = ns.Utils
    local me = U.UnitKey("player")
    if not me then return end
    local now = U.ServerTime()
    local finds = {}
    for i, b in ipairs(self.TEST_BUCKLES) do
        local award = b[3] == "award"
        table.insert(finds, 1, { uid = -i, buckle = b[1], quality = b[2], source = b[3], owner = me,
            foundAt = now - b[5] * 3600, eventAt = now - b[5] * 3600, mapID = not award and 1434 or nil,
            other = not award and b[4] or nil, tournament = award and b[4] or nil, quiet = false })
    end
    ns.SiteData:SetTestBuckles(me, finds, "dead_mans_hand")
    for _, find in ipairs(finds) do shown[tostring(find.uid)] = nil end
    ns:Print(L.SIM_BUCKLES_DONE)
    ns.Buckles:Reveal()
end

-- /hh sim duels [clear] (HH-134): test duel spots in our zone, to see the map mark, the
-- chat line and the invite clicks before a release. Only on our screen: never sent, and
-- the made-up HeadHunters get no whisper (Alerts/DuelSpots.lua).
function Simulator:Duels(kind)
    if kind == "clear" then
        ns:Print(string.format(L.SIM_DUELS_CLEARED, ns.DuelSpots:ClearSim()))
        return
    end
    local zone, others = ns.DuelSpots:Simulate()
    if not zone then
        ns:Print(others == "layer" and L.SIM_DUELS_NO_LAYER or L.SIM_DUELS_NO_ZONE)
        return
    end
    ns:Print(string.format(L.SIM_DUELS, ns.Utils.MapName(zone) or L.UNKNOWN_ZONE, others[1], others[2]))
end

ns.SlashCommands:Register("sim", function(args)
    local kind = table.remove(args, 1)
    kind = kind and kind:lower()
    if kind == "send" then
        Simulator:Send(args)
        return
    end
    if kind == "clear" then
        local removed = Simulator:Clear()
        if removed then
            ns:Print(string.format(L.SIM_CLEARED, removed.reports, removed.deaths, removed.catches))
        end
        return
    end
    if kind == "demo" then
        if args[1] and args[1]:lower() == "clear" then ns.Demo:Clear() else ns.Demo:Run() end
        return
    end
    if kind == "gang" then
        Simulator:Gang(args[1] and args[1]:lower())
        return
    end
    if kind == "event" then
        Simulator:Event(args[1] and args[1]:lower())
        return
    end
    if kind == "duels" then
        Simulator:Duels(args[1] and args[1]:lower())
        return
    end
    if kind == "buckles" then
        Simulator:Buckles(args[1] and args[1]:lower())
        return
    end
    if kind ~= "death" and kind ~= "sighting" then
        print(L.SIM_USAGE_DEATH)
        print(L.SIM_USAGE_SIGHTING)
        print(L.SIM_USAGE_DEMO)
        print(L.SIM_USAGE_CLEAR)
        print(L.SIM_USAGE_DUELS)
        print(L.SIM_USAGE_GANG)
        print(L.SIM_USAGE_BUCKLES)
        if ns.Dev.Present() then print(L.SIM_USAGE_EVENT) end
        return
    end
    local enemy, err = Simulator:ParseEnemy(args)
    if not enemy then
        ns:Print(err or (kind == "death" and L.SIM_USAGE_DEATH or L.SIM_USAGE_SIGHTING))
        return
    end
    if kind == "death" then
        local report = Simulator:BuildDeathReport(enemy)
        ns:Debug("sim death report", report.id)
        ns.Events:Fire("HH_DEATH_REPORT", report, "sim")
        ns:Print(string.format(L.SIM_DEATH, enemy.key, Describe(enemy)))
    else
        ns:Debug("sim sighting", enemy.key)
        ns.Events:Fire("HH_ENEMY_SEEN", enemy, "sim")
        ns:Print(string.format(L.SIM_SIGHTING, enemy.key, Describe(enemy)))
    end
end, L.HELP_SIM)
