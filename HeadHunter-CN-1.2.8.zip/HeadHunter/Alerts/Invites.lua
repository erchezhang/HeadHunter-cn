-- HH-145: the HeadHunters we asked for a group invite from the Battle popup's Help, so
-- each of them gets at most one invite whisper from us per LIMIT (author, 2026-10-12).
-- Three players asking the same HeadHunter are still three whispers; one player clicking
-- again asks the next HeadHunter there, or nobody. The map marks only open a whisper for
-- the player to send, without a limit (author, 2026-10-16).
-- Saved per home in db.invites (compact name -> time asked), so a /reload does not ask
-- again; Core/Database.lua prunes it. Fires HH_INVITE_ASKED(name) after each ask.

local addonName, ns = ...

local Invites = ns:RegisterModule("Invites", {})

Invites.LIMIT = ns.Database.LIMITS.inviteSeconds
-- the game sends at most 255 bytes in one chat message; a Russian letter takes 2, a
-- Korean or Chinese one 3
Invites.TEXT_MAX = 255

-- A whisper text as the game takes it: no pipes (escape codes) or line breaks, trimmed,
-- at most TEXT_MAX bytes, cut between letters (a UTF-8 byte 0x80-0xBF continues the
-- letter before it); nil when nothing is left
function Invites.Clean(text)
    if type(text) ~= "string" then return nil end
    text = text:gsub("[|\r\n]", " "):gsub("^%s+", ""):gsub("%s+$", "")
    if text == "" then return nil end
    local cut = math.min(#text, Invites.TEXT_MAX)
    while cut > 0 and cut < #text and text:byte(cut + 1) >= 0x80 and text:byte(cut + 1) < 0xC0 do
        cut = cut - 1
    end
    return text:sub(1, cut)
end

-- The invite whisper (Join a posse, Help): the player's own text from the options page
-- (alerts.whisperText), else ours
function Invites.WhisperText()
    local settings = ns.db and ns.db.settings
    return Invites.Clean(settings and settings.alerts and settings.alerts.whisperText) or ns.L.INVITE_WHISPER
end

local function Key(name)
    return name and ns.Utils.CompactName(name)
end

local function AskedAt(key)
    local saved = ns.db and ns.db.invites
    return saved and saved[key]
end

-- Seconds until we may ask that HeadHunter again, or nil when we may now
function Invites:Left(name, now)
    local key = Key(name)
    local t = key and AskedAt(key)
    if not t then return nil end
    local left = t + self.LIMIT - (now or ns.Utils.ServerTime())
    return left > 0 and left or nil
end

-- We just asked that HeadHunter
function Invites:Mark(name, now)
    local key = Key(name)
    if not key then return end
    now = now or ns.Utils.ServerTime()
    if ns.db and ns.db.invites then
        ns.db.invites[key] = now
    end
    ns.Events:Fire("HH_INVITE_ASKED", name)
end

-- The first of names we may ask now; or nil and the shortest time until one is free
function Invites:Pick(names, now)
    local shortest
    for _, name in ipairs(names) do
        local left = self:Left(name, now)
        if not left then return name end
        if not shortest or left < shortest then shortest = left end
    end
    return nil, shortest
end

-- Whole minutes for the texts, at least 1
function Invites.Minutes(seconds)
    return math.max(1, math.ceil((seconds or 0) / 60))
end
