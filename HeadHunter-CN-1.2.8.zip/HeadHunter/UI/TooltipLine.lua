-- HH-062: a HeadHunter line on enemy player tooltips.
--
--   WANTED enemy:           "WANTED · Ganker · 8 kills · Coward, Gunslinger"
--   known, not WANTED now:  "HeadHunter: 12 kills known · caught 1x · Coward" (grey)
--   unknown enemy:          nothing
--   any player with duels:  "High Noon: Deadeye #3 (1250)" (HH-093)
--   a player's bounty:      "Bounty: 20g by Tallon · Camped me" (HH-118)
--   a tournament organizer: "★ Tournament host: Gate Brawl · in progress" (HH-128, any player)
--   a gang member:          "Gang: Black Hand" (HH-155, any player of the website's gangs)
--   a worn buckle:          "[buckle] Hunter's Bane" (HH-161, any player who wears one)
--
-- Hook: TooltipDataProcessor (unit post-call) where the client has it, else the
-- tooltip's OnTooltipSetUnit script. Either may run more than once for one tooltip,
-- so the line is added once until the tooltip is cleared. /hh tooltip turns it off.
--
-- Tooltip addons that redraw the player tooltip (author, 2026-11-15: TacoTip on WoW
-- Forever drops every row under the name, guild and level and writes its own) end with
-- the tooltip's Show(); a hook there adds back any of our lines that went missing.
--
-- TooltipLine.Lines(entry) is the pure part (tested offline).

local addonName, ns = ...
local L = ns.L

local TooltipLine = ns:RegisterModule("TooltipLine", {})

local OWNER = "TooltipLine"

-- Lines to add for one enemy entry: array of { text, r, g, b }
function TooltipLine.Lines(entry)
    if not entry then return {} end
    local Wanted = ns.Wanted
    local badges = Wanted.BadgeNames(entry)
    local suffix = badges ~= "" and (" · " .. badges) or ""
    if entry.wanted then
        local line = string.format(L.TOOLTIP_WANTED, Wanted.RankName(entry.rank), math.floor(entry.kills)) .. suffix
        local lines = { { line, 1, 1, 1 } }
        local posse = ns.Posse:Summary(entry.id)
        if posse then lines[2] = { posse, 0.6, 0.8, 1 } end
        return lines
    end
    if entry.atLarge then
        local line = string.format(L.TOOLTIP_AT_LARGE, Wanted.RankName(entry.lastRank), entry.killCount or 0)
        return { { line .. suffix, 1, 0.75, 0.5 } }
    end
    if (entry.killCount or 0) == 0 then return {} end
    local line = string.format(L.TOOLTIP_KNOWN, entry.killCount)
    return { { line .. suffix, 0.7, 0.7, 0.7 } }
end

-- The enemy on a unit token, or nil
function TooltipLine.EntryForUnit(unit)
    local U = ns.Utils
    if not unit or not U.UnitIsEnemyPlayer(unit) then return nil end
    local key = U.UnitKey(unit)
    local entry = key and ns.Wanted:ByKey(key)
    if entry then return entry end
    local guid = U.UnitGUID(unit)
    return guid and ns.Wanted:Get("guid:" .. guid)
end

-- HH-093: "High Noon: Deadeye #3 (1250)" on any player (friend or foe) with duels.
-- HH-159: then the all-duels record, "· 42-17 all duels".
-- HH-137: out-of-date lists are counted again; until then the last counted title shows.
function TooltipLine.DuelLine(unit)
    local U = ns.Utils
    if not unit or not U.UnitIsPlayer(unit) then return nil end
    ns.HighNoon:Ensure()
    local player = ns.HighNoon:Get(U.UnitKey(unit))
    local title = ns.HighNoon.Title(player)
    if not title then return nil end
    return { string.format(L.DUEL_TOOLTIP, title) .. " · " .. ns.HighNoon.AllText(player), 1, 1, 1 }
end

-- HH-155: "Gang: Black Hand" on any player in one of the website's gangs
function TooltipLine.GangLine(unit)
    local U = ns.Utils
    if not unit or not U.UnitIsPlayer(unit) then return nil end
    local gang = ns.Gangs:Of(U.UnitKey(unit))
    return gang and { string.format(L.GANG_TOOLTIP, gang), 1, 0.82, 0 } or nil
end

-- HH-161: the buckle's picture in the tooltip, in pixels high (26 wide)
TooltipLine.BUCKLE_HEIGHT = 19

-- HH-161: the buckle a player wears, with its picture, in its quality's colour
function TooltipLine.BuckleLine(unit)
    local U = ns.Utils
    if not unit or not U.UnitIsPlayer(unit) then return nil end
    local worn = ns.SiteData:WornBuckle(U.UnitKey(unit))
    if not worn then return nil end
    local B = ns.Buckles
    return { B.Icon(worn.buckle, worn.quality, TooltipLine.BUCKLE_HEIGHT) .. " " .. B.ColoredName(worn.buckle, worn.quality, worn.name), 1, 1, 1 }
end

function TooltipLine:Enabled()
    return ns.db ~= nil and ns.db.settings.tooltip ~= false and ns.Guards:IsActive()
end

-- tooltip: the GameTooltip-like frame being filled
function TooltipLine:Fill(tooltip)
    if not self:Enabled() or not tooltip or tooltip.hhLineAdded then return end
    local U = ns.Utils
    local _, unit = U.SafeCall(tooltip.GetUnit, tooltip)
    unit = U.AccessibleString(unit)
    local entry = self.EntryForUnit(unit)
    local lines = self.Lines(entry)
    local bounty = entry and ns.Bounties:Line(entry.id)
    if bounty then lines[#lines + 1] = { bounty, 1, 0.82, 0 } end
    local duel = self.DuelLine(unit)
    if duel then lines[#lines + 1] = duel end
    local gang = self.GangLine(unit)
    if gang then table.insert(lines, 1, gang) end
    local buckle = self.BuckleLine(unit)
    if buckle then lines[#lines + 1] = buckle end
    -- HH-128: the sheriff's star on a tournament's host or co-organizer (any player)
    local organizer = ns.Organizers:TooltipLine(unit)
    if organizer then table.insert(lines, 1, organizer) end
    if #lines == 0 then return end
    tooltip.hhLineAdded = true
    tooltip.hhLines = lines
    for _, line in ipairs(lines) do
        tooltip:AddLine(line[1], line[2], line[3], line[4])
    end
end

-- Most times our lines are put back for one tooltip, so two addons that each redraw
-- after the other can never loop
TooltipLine.MAX_RESTORES = 2

-- The texts of the tooltip's shown left rows, as a set
local function ShownTexts(tooltip)
    local U = ns.Utils
    local shown = {}
    local name = U.SafeCall(tooltip.GetName, tooltip)
    local count = tonumber(U.SafeCall(tooltip.NumLines, tooltip)) or 0
    for i = 1, count do
        local row = name and _G[name .. "TextLeft" .. i]
        local text = row and U.AccessibleString(U.SafeCall(row.GetText, row))
        if text and U.SafeCall(row.IsShown, row) ~= false then shown[text] = true end
    end
    return shown
end

-- Our lines another addon took off the tooltip since we added them: array of { text, r, g, b }
function TooltipLine.Missing(tooltip)
    local lines = tooltip and tooltip.hhLines
    if not lines then return {} end
    local shown = ShownTexts(tooltip)
    local missing = {}
    for _, line in ipairs(lines) do
        if not shown[line[1]] then missing[#missing + 1] = line end
    end
    return missing
end

-- After the tooltip's Show(): our lines again at the bottom, if another addon took them off
function TooltipLine:Restore(tooltip)
    if not tooltip or tooltip.hhRestoring or (tooltip.hhRestores or 0) >= self.MAX_RESTORES then return end
    local missing = self.Missing(tooltip)
    if #missing == 0 then return end
    tooltip.hhRestores = (tooltip.hhRestores or 0) + 1
    tooltip.hhRestoring = true
    for _, line in ipairs(missing) do
        tooltip:AddLine(line[1], line[2], line[3], line[4])
    end
    pcall(tooltip.Show, tooltip)
    tooltip.hhRestoring = nil
end

local function HookCleared(tooltip)
    if tooltip and tooltip.HookScript then
        pcall(tooltip.HookScript, tooltip, "OnTooltipCleared", function(self)
            self.hhLineAdded, self.hhLines, self.hhRestores = nil, nil, nil
        end)
    end
    if tooltip and hooksecurefunc and type(tooltip.Show) == "function" then
        pcall(hooksecurefunc, tooltip, "Show", function(self)
            local ok, err = pcall(TooltipLine.Restore, TooltipLine, self)
            if not ok then ns:Error(err) end
        end)
    end
end

-- Returns "processor", "script" or nil (nothing to hook)
function TooltipLine:Install()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType
            and Enum.TooltipDataType.Unit then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tooltip)
            local ok, err = pcall(TooltipLine.Fill, TooltipLine, tooltip)
            if not ok then ns:Error(err) end
        end)
        HookCleared(GameTooltip)
        return "processor"
    end
    if GameTooltip and GameTooltip.HookScript then
        local ok = pcall(GameTooltip.HookScript, GameTooltip, "OnTooltipSetUnit", function(tooltip)
            local fine, err = pcall(TooltipLine.Fill, TooltipLine, tooltip)
            if not fine then ns:Error(err) end
        end)
        if ok then
            HookCleared(GameTooltip)
            return "script"
        end
    end
    return nil
end

ns.Events:Register("HH_INITIALIZED", function()
    TooltipLine.hook = TooltipLine:Install()
    ns:Debug("Tooltip line hook:", tostring(TooltipLine.hook))
end, OWNER)

ns.SlashCommands:Register("tooltip", function(args)
    local mode = args[1] and args[1]:lower()
    if mode == "on" or mode == "off" then
        ns.Database:SetSetting("tooltip", mode == "on")
    else
        ns.Database:SetSetting("tooltip", not TooltipLine:Enabled())
    end
    ns:Print(TooltipLine:Enabled() and L.TOOLTIP_ON or L.TOOLTIP_OFF)
end, L.HELP_TOOLTIP)
